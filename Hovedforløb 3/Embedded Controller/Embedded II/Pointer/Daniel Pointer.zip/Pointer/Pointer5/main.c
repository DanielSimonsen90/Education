/*
 * Pointer5.c
 *
 * Created: 6/3/2021 12:33:13 PM
 * Author : dani146d
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

