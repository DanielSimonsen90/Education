/*
 * MyTimer.h
 *
 * Created: 6/7/2021 1:31:46 PM
 *  Author: dani146d
 */ 


#ifndef MYTIMER_H_
#define MYTIMER_H_

extern void SetupTimer();
extern void EnableTimer();
extern void DisableTimer();

#endif /* MYTIMER_H_ */