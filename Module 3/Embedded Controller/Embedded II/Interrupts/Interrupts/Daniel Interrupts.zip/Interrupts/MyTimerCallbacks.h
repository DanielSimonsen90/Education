/*
 * MyTimerCallbacks.h
 *
 * Created: 16-06-2021 13:42:03
 *  Author: dani146d
 */ 

#include <avr/io.h>

#ifndef MYTIMERCALLBACKS_H_
#define MYTIMERCALLBACKS_H_

extern uint32_t TimerCallbackOne();
extern uint32_t TimerCallbackTwo();
extern uint32_t TimerCallbackThree();

#endif /* MYTIMERCALLBACKS_H_ */